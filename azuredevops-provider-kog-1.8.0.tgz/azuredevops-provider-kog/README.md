
This is a Helm chart for deploying the Azure DevOps Provider KOG.
It acts as a umbrella chart and it includes all the other blueprints:
- azuredevops-provider-kog-buildpermission-blueprint
- azuredevops-provider-kog-gitrepository-blueprint
- azuredevops-provider-kog-graphgroup-blueprint
- azuredevops-provider-kog-membership-blueprint
- azuredevops-provider-kog-pipeline-blueprint
- azuredevops-provider-kog-pipelinepermission-blueprint
- azuredevops-provider-kog-policyconfiguration-blueprint
- azuredevops-provider-kog-project-blueprint
- azuredevops-provider-kog-pullrequest-blueprint
- azuredevops-provider-kog-repositorypermission-blueprint
- azuredevops-provider-kog-team-blueprint
- azuredevops-provider-kog-user-blueprint
