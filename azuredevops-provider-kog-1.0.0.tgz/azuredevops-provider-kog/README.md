
This is a Helm chart for deploying the Azure DevOps Provider KOG Blueprint.
It acts as a umbrella chart and it includes all the other blueprints:
- azuredevops-provider-kog-gitrepository-blueprint
- azuredevops-provider-kog-pipeline-blueprint
- azuredevops-provider-kog-pipelinepermission-blueprint
